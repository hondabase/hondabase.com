
/************************************************************************
 *																								*
 *		Z80 Disassembler - Copyright (C) 1996-2002 by							*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *		theposts@soca.com																	*
 *																								*
 *		DZ80.C - Main File																*
 *																								*
 *		Version 3.0 - 01/31/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<string.h>
#include	<time.h>

#include	"dz80.h"
#include	"dz80p1.h"
#include	"dz80p2.h"

#ifdef	MSDOS
#include	<dos.h>
#include	<alloc.h>
#endif

#ifdef	LINUX
#include	<malloc.h>
#endif

/******************************************************************
 *																						*
 *								Global variables									*
 *																						*
 *	Note that the pgmmem and pgmflags pointers are huge pointers.	*
 *	This is necessary even in the compact memory model since			*
 *	pointer arithmetic is NOT handled properly by BCC unless			*
 *	the huge keyword is used.													*
 *																						*
 ******************************************************************/

char	src[FN_LEN], dst[FN_LEN];	/* file name buffers				*/
char	ctl[FN_LEN];					/* control file name				*/
char	alt_ctl[FN_LEN];				/* alternate control file name*/
char	temp_fn[FN_LEN];				/* temp file name buffer		*/
char	linebuffer[MAX_LINE];		/* input line buffer				*/
FILE	*fp;								/* dos file struct				*/
int	hexflag;							/* append hex flag				*/
int	fileflag;						/* file type flag					*/
int	kcnt;								/* output char counter			*/
word	pc;								/* current program counter		*/
word	himark;							/* highest data adrs				*/
word	offset;							/* program counter offset		*/

#ifdef	MSDOS

byte	huge *pgmmem;					/* program data pointer			*/
byte	huge *pgmflags;				/* pointer to program flags	*/
byte	huge *cmtflags;				/* comment flags					*/

#else

byte	*pgmmem;							/* program data pointer			*/
byte	*pgmflags;						/* pointer to program flags	*/
byte	*cmtflags;						/* comment flags					*/

#endif

char	string[ASCLIMIT];				/* ascii data for defb			*/
word	asc_cnt;							/* count for string data		*/
byte	byte_data[BYTELIMIT];		/* binary data for defb			*/
word	byte_cnt;						/* count for binary data		*/
word	word_data[WORDLIMIT];		/* binary data for defw			*/
word	word_cnt;						/* count for word data			*/
byte	dump;								/* dump just done flag			*/
byte	ascii_flag;						/* use ascii string flag		*/
struct sym	*sym_tab;				/* symbol table pointer			*/
struct sym	*lab_tab;				/* label table pointer			*/
struct sym	*sym_tab_last;			/* last symbol table pointer	*/
struct sym	*lab_tab_last;			/* lastlabel table pointer		*/
char	defbstr[8];						/* string for defined bytes	*/
char	defwstr[8];						/* string for defined words	*/
char	ascistr[8];						/* string for defined ascii	*/
word	symbol_count;					/* number of symbols				*/
word	label_count;					/* number of labels				*/
struct comment	*comment_list;

/*********************
 *							*
 *			Code			*
 *							*
 *********************/

void usage(void)
{
	printf("\nUsage: dz80 <filename> [options]\n"
		"Options may be entered Unix style (-d) or DOS style (/b)\n"
		"\t-d include address and data in comment field.\n"
		"\t-x add hexadecimal offset to program addresses.\n"
		"\t-s change 'db' and 'dw' to 'defb' and 'defw'.\n"
		"\t-b force .bin extension on input file.\n"
		"\t-h force .hex extension on input file.\n"
		"\t   If neither 'b' nor 'h' is specified, DZ80 will first search\n"
		"\t   for a .hex file, and if not found, then a .bin file.\n\n"
		"Options may be entered in a freeform fashion as long "
		"as a dash (-) or\n"
		"a slash (/) preceeds any option that preceeds the filename."
		"\nExamples:\n"
		"\tdz80 filename bd\n"
		"\tdz80 -d filename b\n"
		"\tdz80 /b -d filename\n");
	exit(GOOD_EXIT);
}

#ifdef	LINUX             /* Linux C lib does not have strrev() */

void strrev(char *str)
{
	int	 i, j, len;
	char	bfr[FN_LEN];

	len = strlen(str) - 1;
	for (i=0, j=len; j >= 0 ; i++, j--)
		bfr[i] = str[j];
	bfr[i] = '\0';
	strcpy(str, bfr);
}

#endif

/*********************************
 *											*
 *			The Main Program			*
 *											*
 *********************************/

int main(int argc, char *argv[])
{
	char	c;
	word	count;
	int	i, j;
	char	*inp;
	int	line;
	char	*cptr;

	printf("\nDZ80 Z80 Disassembler V %d.%d"
			 "\nCopyright (C) 1996-2002 by J. L. Post"
			 "\nReleased under the GNU General Public License\n",
		VERNO, REVNO);
	if (argc < 2)
		usage();

/*******************************
	find filename in command line
 *******************************/

	for (line=1; line<argc; line++)	/* find first non option string */
	{
		inp = argv[line];
		c = *inp;
		if (c == '?')						/* '?' without preceeding '-' or '/' */
			usage();
		if (c == '-' || c == '/')
		{
			if (*(++inp) == '?')			/* '?' following '-' or '/' */
				usage();
		}
		else
		{										/* assume first found is file name */
			cptr = argv[line];
			strcpy(src, cptr);			/* init filenames */
			strcat(src, ".hex");			/* assume search for .hex first */
			strcpy(alt_ctl, cptr);
			strcat(alt_ctl, ".ctl");
			i = strlen(cptr) - 1;
			for (j=0; i >= 0; i--)
			{
				if (cptr[i] != '\\' && cptr[i] != ':' && cptr[i] != '/')
					temp_fn[j++] = cptr[i];
				else
					break;
			}
			temp_fn[j] = '\0';
			strrev(temp_fn);
			strcpy(dst, temp_fn);
			strcat(dst, ".z80");
			strcpy(ctl, temp_fn);
			strcat(ctl, ".ctl");
			break;
		}
	}
	strcpy(defbstr, "db");				/* init define byte and word strings */
	strcpy(defwstr, "dw");
	strcpy(ascistr, "db");				/* init define ascii string */

	sym_tab = NULL;						/* no symbols or labels yet */
	lab_tab = NULL;
	fileflag = EITHERFILE;				/* assume search for either file type */
	hexflag = FALSE;						/* no data in comment field */
	fp = NULL;
	offset = 0;								/* default start at address 0 */
	ascii_flag = FALSE;

/******************************
	process command line options
 ******************************/

	if (argc > 2)							/* test for options */
	{
		for (count=1; count<argc; count++)
		{
			inp = argv[count];			/* to avoid modifying pointer in argv */
			c = (char) toupper(*inp++);
			while (c)
			{
				if (c == '-' || c == '/')
					c = toupper(*inp++);		/* skip over option specifier */

				if (c == '?')
					usage();

				if (count == line)			/* skip if already identified */
					break;						/* as the file name */

				if (c == 'X')					/* add hex offset to program */
				{
					offset = atox(inp);
					break;
				}

				else if (c == 'D')			/* add data in comment field */
					hexflag = TRUE;

				else if (c == 'B')			/* binary instead of hex file */
				{
					fileflag = BINFILE;
					strcpy(src, argv[line]);
					strcat(src, ".bin");
				}

				else if (c == 'H')			/* force search for hex file */
				{
					fileflag = HEXFILE;
					strcpy(src, argv[line]);
					strcat(src, ".hex");
				}

				else if (c == 'S')			/* change db/dw strings */
				{
					strcpy(defbstr, "defb");
					strcpy(defwstr, "defw");
					strcpy(ascistr, "defb");
				}

				else if (c == 'A')			/* use ascii macro */
				{
					strcpy(ascistr, "ascii");
					ascii_flag = TRUE;
				}
				c = (char) toupper(*inp++);
			}
		}
	}

/******************
	open source file
 ******************/

	switch (fileflag)
	{
		case EITHERFILE:				/* if no type specified... */
			fp = fopen(src, "r");	/* search for hex file first */
			if (fp == NULL)			/* if not found, search for bin file */
			{
				fileflag = BINFILE;
				strcpy(src, argv[line]);
				strcat(src, ".bin");
				fp = fopen(src, "rb");
				if (fp == NULL)
				{
					printf("* Can't open either '%s.hex' nor '%s.bin' *\n",
						argv[line], argv[line]);
					exit(FILE_ERROR);
				}
				else
					fileflag = BINFILE;
			}
			break;

		case HEXFILE:					/* force hex file */
			fp = fopen(src, "r");
			break;

		case BINFILE:					/* force bin file */
			fp = fopen(src, "rb");
			break;
	}
	if (fp == NULL)					/* if file not found... */
	{
		printf("* Can't open file '%s' *\n", src);
		exit(FILE_ERROR);
	}

/*****************************************
	allocate memory for program and flags
 *****************************************/

#ifdef	MSDOS
	if ((pgmmem = (byte huge *) farmalloc(PMEMSIZE)) == NULL)
#else
	if ((pgmmem = (byte *) malloc(PMEMSIZE)) == NULL)
#endif
	{
		printf("INTERNAL ERROR! - Can't allocate program space!\n");
		exit(MEM_ERROR);
	}

#ifdef	MSDOS
	if ((pgmflags = (byte huge *) farmalloc(PMEMSIZE)) == NULL)
#else
	if ((pgmflags = (byte *) malloc(PMEMSIZE)) == NULL)
#endif
	{
		printf("INTERNAL ERROR! - Can't allocate flag space!\n");
		exit(MEM_ERROR);
	}

#ifdef	MSDOS
	if ((cmtflags = (byte huge *) farmalloc(PMEMSIZE)) == NULL)
#else
	if ((cmtflags = (byte *) malloc(PMEMSIZE)) == NULL)
#endif
	{
		printf("INTERNAL ERROR! - Can't allocate comment flag space!\n");
		exit(MEM_ERROR);
	}

	printf("Initializing program spaces...");
	for (count=0xffff; count; --count)			/* fill code space with	*/
	{
		pgmmem[count] = NO_DATA;					/* invalidate data	*/
		pgmflags[count] = PF_INIT;					/* invalidate flags	*/
		cmtflags[count] = 0;
	}
	pgmmem[0] = NO_DATA;								/* include first location */
	pgmflags[0] = PF_INIT;
	cmtflags[0] = 0;

/***************************************
	read input file and set up data array
 ***************************************/

	himark = 0;
	line = 0;
	pc = offset;
	printf("\nreading %s\n", src);

	if (fileflag == BINFILE)				/* if binary file... */
	{
		while (!feof(fp))							/* until end of file... */
		{
			i = fread(linebuffer, 1, 128, fp);	/* read a block of data */
			for (j=0; j<i; j++)
			{
				pgmmem[pc] = linebuffer[j];	/* copy to program space */
				pgmflags[pc] = PF_DATA;
				pc++;
				if ((pc & 0xff) == 0)
					printf("\r%04x", pc);		/* show progress */
			}
			himark = pc - 1;						/* flag highest location */
		}
	}

	else											/* else hex file... */
	{
		while (!feof(fp))							/* until end of file... */
		{
			*linebuffer = '\0';					/* clear previous line */
			fgets(linebuffer, 127, fp);		/* read one line */
			line++;
			inp = linebuffer;						/* local copy of pointer */
			if (sscanf(inp, "%*c%2x%4x", &i, &pc) != EOF)
														/* get count and address */
			{
				pc += offset;						/* add offset to address */
				if (i == 0)
					break;							/* done if end of hex record */
				if (i > 64)							/* oops! line too long */
				{
					printf("invalid count (%d) in line %d:\n", i, line);
					printf("%s", linebuffer);
					exit(FILE_ERROR);
				}
				for (j=0; j<i ; j++)				/* now move data to program area */
				{
					getcode(inp + 9 + j * 2, &pgmmem[pc]);	/* code to program space */
					pgmflags[pc] = PF_DATA;				/* flag valid data */
					pc++;

					if ((pc & 0xff) == 0)				/* show progress */
						printf("\r%04x", pc);
				}
			}
			--pc;
			if (pc > himark)
				himark = pc;							/* update last address */
		}
	}
	fclose(fp);										/* done reading input file */

	printf("\rHighest location = %04x\n", himark);	/* show last location */

/********************************************************
	Got the program in data array, now let's go to work...
 ********************************************************/

	symbol_count = 0;
	label_count = 0;

	pass0();								/* read control file					*/
	pass1();								/* find internal references		*/
	pass2();								/* disassemble to output file		*/
	pass3();								/* generate equ's for references	*/
	printf("\nDone");					/* go bye-bye							*/
	return(GOOD_EXIT);
}								/*  End of Main */

/***************************************************
 *																	*
 *	Convert ascii hex to hexadecimal for X option	*
 *																	*
 ***************************************************/

word atox(char *str)
{
	char	c;
	word	i;

	i = 0;
	c = (char) toupper(*str++);
	while (c)
	{
		if (isxdigit((int) c))
		{
			c = (c > '9') ? c - 0x37 : c & 0xf;
			i = (i << 4) | c;
		}
		else
			break;
		c = (char) toupper(*str++);
	}
	return(i);
}

/******************************************
 *														*
 *	Put ascii hex data into binary array	*
 *														*
 ******************************************/

#ifdef	MSDOS

void getcode(char *from, byte huge *loc)

#else

void getcode(char *from, byte *loc)

#endif

{
	byte	c, i;

	c = *from++ - 0x30;
	c = (c > 10) ? c - 7 : c;
	i = c << 4;
	c = *from++ - 0x30;
	c = (c > 10) ? c - 7 : c;
	*loc = i | c;
}

/***************************************************************
 *																					*
 *							Find symbol or label								*
 *																					*
 *		Binary search using table of pointers to list nodes.		*
 *		This search is based on the fact that:							*
 *					list[first-1] � key < list[last+1]					*
 *		is an invariant. This allows the while loop to involve	*
 *		only one boolean expression, rather than two. The 'if'	*
 *		statement also involves only one boolean expression.		*
 *		The test for equality (has it been found?) is not done	*
 *		until the loop is complete. This significantly speeds		*
 *		up the search compared to a standard binary search.		*
 *																					*
 ***************************************************************/

char *find_entry(word val, word count, SYM_PTR *table)
{
	struct sym	*ptr;
	word			first, mid, last;
	char			*ret;

	first = 1;
	last = count;
	while (first <= last)				/* while more to search... */
	{
		mid = (first + last) >> 1;		/* begin in middle of remaining array */
		ptr = table[mid - 1];			/* get pointer to node */
		if (ptr->val > val)				/* determine which way to go */
			last = mid - 1;				/* search before midpoint */
		else
			first = mid + 1;				/* search after midpoint */
	}
	ret = NULL;								/* assume not found */
	if (last > 0)							/* are we still within the array? */
	{
		ptr = table[last - 1];			/* if so, get last pointer */
		if (val == ptr->val)				/* is it what we're searching for? */
		{
			ptr->used = 1;					/* label/symbol has been used */
			ret = ptr->name;				/* return pointer to caller */
		}
	}
	return(ret);
}

/************************************************************
 *																				*
 *		Allocate new entry in symbol table or label table		*
 *																				*
 ************************************************************/

struct sym *get_smem(int type, int req_size)
{
	struct sym	*ptr;

	ptr = (struct sym*) malloc(sizeof(struct sym) + req_size + 1);
																/* get memory from OS */
	if (ptr == NULL)										/* what? out of memory?... */
	{
		printf("\nINTERNAL ERROR! - No memory for ");
		if (type)
			printf("label");
		else
			printf("symbol");
		printf(" table!\n");
		exit(MEM_ERROR);
	}
	ptr->next = NULL;
	return(ptr);						/* give caller the address */
}

/***************************************
 *													*
 *		Add symbol or label to table		*
 *  Symbol if type == 0, else label.	*
 *													*
 ***************************************/

void add_entry(word val, char *symbol, int type)
{
	struct sym	*nptr, *tbl_ptr;
	char			*cptr;
	char			tbl_name[8];

	cptr = symbol;				/* ensure that input string is null terminated */
	while (*cptr)
	{
		if (!isgraph(*cptr))
			break;
		cptr++;
	}
	*cptr = '\0';

	if (type)
	{
		tbl_ptr = lab_tab;				/* get pointer to correct table */
		strcpy(tbl_name, "label");
		label_count++;
	}
	else
	{
		tbl_ptr = sym_tab;
		strcpy(tbl_name, "symbol");
		symbol_count++;
	}

	nptr = get_smem(type, strlen(symbol));
	if (tbl_ptr == NULL)					/* if first symbol or label... */
	{
		if (type)							/* initialize head pointer */
			lab_tab = nptr;
		else
			sym_tab = nptr;
	}
	else
	{
		if (type)							/* get pointer to end of correct table */
			lab_tab_last->next = nptr;
		else
			sym_tab_last->next = nptr;
	}
	if (type)
		lab_tab_last = nptr;
	else
		sym_tab_last = nptr;
	nptr->used = 0;
	nptr->val = val;						/* set value in new entry */
	strcpy(nptr->name, symbol);		/* and copy text to entry */
}

/* end of dz80.c */

