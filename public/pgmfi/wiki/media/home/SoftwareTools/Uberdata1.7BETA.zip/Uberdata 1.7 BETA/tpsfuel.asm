org 0000h					; jump to 7250 from 14ac
		L      A, ACC
                MOV    er0, A
                MOV    DP, #07A0Dh
                LC     A, [DP]
                MUL
                ROL    A
                L      A, er1
                ROL    A
                ADD    A, off(00144h)
		JGE    END
                L      A, #0ffffh
END:
		J      014B3h
