
/*  DZ80TBL.H - Copyright 1990-99 by J. L. Post
 *  10/23/99
 *  Mnemonic Table for Z80 Disassembler
 */

extern struct mnementry mnemtbl[];
extern struct snementry cbtbl[];
extern struct snementry regtbl[];
extern struct snementry ddcbtbl[];
extern struct mnementry dd1tbl[];
extern struct mnementry dd2tbl[];
extern struct mnementry edtbl[];
extern unsigned char opttbl[];
extern unsigned char edcode[];
extern unsigned char ddcode[];

/*  End of dz80tbl.h */

