
/************************************************************************
 *																								*
 *		Z80 Disassembler - Copyright (C) 1996-2002 by							*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *																								*
 *		DZ80P2.H - Disassembly Passes 2 & 3											*
 *																								*
 *		Version 2.1 - 01/14/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

/***************************
 *									*
 *		Defined Constants		*
 *									*
 ***************************/

/*
	This ugly looking thing is used in pass 3 to determine whether
	a miscellaneous equate statement should be generated. The equate
	statement will be written to the disassembly file if the location
	is referenced by some instruction and either it is a split reference
	or the location is uninitialized and the location does not have an
	entry in the label table. If the above requirements are met except
	that the location has an entry in the label table, then an equate
	statement will be generated as a label equate.
*/

#define	MISC_EQU_TAG	\
((pflag & PF_REF) && \
!(pflag & PF_CLREF) && \
((pflag & PF_SPLIT) | (pflag & PF_NOINIT)))

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

extern void	pass2(void);
extern void	pass3(void);
extern void	invalided(byte k);
extern word	doindex(word i, char index);
extern void	indxld1(word i, char reg, char idx);
extern void	indxld2(word i, char reg, char idx);
extern void	doopcode(char *mnem);
extern void	chk_ref(word i);
extern void	splitcheck(word i);
extern void	puthex(word j);
extern int	ascii(int i);
extern int	is_ascii(byte data);

/***************************
 *									*
 *		Global variables		*
 *									*
 ***************************/

extern int	newline;								/* just output newline flag	*/

#ifdef	MSDOS
extern struct date	date_data;					/* disassembly date				*/
extern struct time	time_data;					/* disassembly time				*/
#endif

#ifdef	LINUX
extern struct tm	*date_time;					/* disassembly time				*/
#endif

extern int	opcount;								/* bytes/opcode count			*/

/* end of dz80p2.h */

