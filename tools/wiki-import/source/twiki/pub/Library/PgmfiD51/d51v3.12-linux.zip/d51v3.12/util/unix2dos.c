
/************************************************************
 *																				*
 *                      UNIX2DOS.C                          *
 *																				*
 * This utility can be compiled for either DOS or UNIX.		*
 * It reads a DOS source file, converts tabs to spaces,		*
 * and converts single LFs to CR/LF pairs.						*
 *																				*
 *		V 1.0 - 08/10/96	Initial version.							*
 *		V 2.0	- 11/06/98	Added wildcard processing.				*
 *																				*
 *		This program and its source code are placed in the		*
 *		public domain with no restrictions whatsoever.			*
 *		Jeffery L. Post													*
 *																				*
 ************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<string.h>
#include	<dir.h>

#define	VERSION	2
#define	REVISION	0

#define	BFR_SIZE	512		/* I/O buffer size			*/
#define	CR			0x0d		/* ascii carriage return	*/
#define	LF			0x0a		/* ascii line feed			*/
#define	CTRLZ		0x1a		/* ascii control z			*/
#define	MAX_FILE	500		/* max number of files		*/
#define	FN_SIZE	32			/* file name size				*/

struct ffblk	finfo;

FILE	*fpi;
FILE	*fpo;
char	fname[FN_SIZE];
char	fnames[MAX_FILE][FN_SIZE];
char	tmpfn[FN_SIZE];
char	bfr_in[BFR_SIZE];
char	bfr_out[2 * BFR_SIZE];		/* bigger in case lots of tabs */

int main(int argc, char *argv[])
{
	int	i, j, k, count, next;

	if (argc < 2)
	{
		printf("\nUNIX2DOS v%d.%02d", VERSION, REVISION);
		printf("\nConverts newlines from unix LF to dos CR/LF");
		printf("\nUsage: unix2dos filename\n");
		exit(1);
	}

	if (findfirst(argv[1], &finfo, 0))
	{
		printf("\nNo file found\n");
		return(1);
	}

	count = 1;
	strcpy((char *) &fnames[0][0], finfo.ff_name);

	next = 0;
	while (1)
	{
		i = findnext(&finfo);
		if (i < 0)
			break;
		else
			strcpy((char *) &fnames[count][0], finfo.ff_name);
		count++;
		if (count >= MAX_FILE)
		{
			printf("\nToo many files!\n");
			exit(1);
		}
	}

	for (next=0; next<count; next++)
	{
		strcpy(fname, (char *) &fnames[next][0]);
		fpi = fopen(fname, "rb");
		if (fpi == NULL)
		{
			printf("\nCan't open '%s'\n", fname);
			exit(1);
		}
		if (tmpnam((char *) &tmpfn) == NULL)
		{
			printf("\nCan't get temp filename\n");
			fclose(fpi);
			exit(1);
		}
		fpo = fopen(tmpfn, "w");
		if (fpo == NULL)
		{
			printf("Can't open temp file\n");
			fclose(fpi);
			exit(1);
		}

		printf("\nprocessing %s", fname);

		i = 1;
		while (i)
		{
			i = fread(bfr_in, 1, BFR_SIZE, fpi);
			for (j=0, k=0; j<i; j++)
			{
				if (bfr_in[j] == CTRLZ)				/* done if end of file */
				{
					i = 0;
					break;
				}
				bfr_out[k++] = bfr_in[j];
			}
			if (k)
				fwrite(bfr_out, 1, k, fpo);
		}
		fclose(fpi);
		fflush(fpo);
		fclose(fpo);
		remove(fname);
		rename(tmpfn, fname);
	}
	printf("\n");
	return(0);
}

/* end of unix2dos.c */

