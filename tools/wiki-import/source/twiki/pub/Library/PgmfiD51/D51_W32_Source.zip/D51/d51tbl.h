
/************************************************************************
 *																								*
 *		D51 8051/52 Disassembler - Copyright (C) 1995-2002 by					*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *		theposts@soca.com																	*
 *																								*
 *		D51TBL.H - Header File															*
 *																								*
 *		Version 3.0 - 01/13/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

#ifndef _D51TBL_H_
#define _D51TBL_H_

/***************************
 *									*
 *		Defined Constants		*
 *									*
 ***************************/

/* none */

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

/* none */

/***************************
 *									*
 *		Global Variables		*
 *									*
 ***************************/

extern struct mnementry	mnemtbl[];
extern unsigned char		opttbl[];
extern struct sfrent		sfr[128];
extern struct sfrent		sfrbits[];
extern struct sfrent		membits[];
extern struct sfrent		keilmembits[];
extern struct sfrent		rbname[];

/* end of d51tbl.h */

#endif