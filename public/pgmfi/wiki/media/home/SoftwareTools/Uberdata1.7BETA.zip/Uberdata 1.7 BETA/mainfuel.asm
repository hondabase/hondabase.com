org 0000h					; called from 14ac
		CAL    04f17h
		L      A, ACC
		MOV    er0, A
		MOV    DP, #07A0Fh
		LC     A, [DP]
		MUL
		ROL    A
		L      A, er1
		ROL    A
		RT
