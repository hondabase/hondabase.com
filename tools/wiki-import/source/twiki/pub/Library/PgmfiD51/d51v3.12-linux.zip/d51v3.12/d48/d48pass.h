
/************************************************************************
 *																								*
 *		D48 8048/41 Disassembler - Copyright (C) 1995-1996 by					*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *																								*
 *		D48PASS.H - Header File															*
 *																								*
 *		Version 2.1 - 10/29/99															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

extern void	pass1(void);
extern void	pass2(void);
extern void	pass3(void);
extern void	doopcode(char *str);
extern void	splitcheck(word i);
extern void	chk_ref(word i);
extern int	is_ascii(byte data);
extern int	ascii(int i);
extern void	puthex(word j);
extern void	dump_ascii(word adrs);
extern void	dump_bytes(word adrs);

#ifdef	DEBUG
extern void	dump_flags(void);
#endif


/***************************
 *									*
 *		Global variables		*
 *									*
 ***************************/

extern int	newline;

#ifdef	MSDOS
extern struct date	date_data;			/* disassembly date				*/
extern struct time	time_data;			/* disassembly time				*/
#endif

#ifdef	LINUX
extern struct tm	*date_time;				/* disassembly time				*/
#endif

/* end of d48pass.h */

