
/************************************************************
 *																				*
 *								SRCCAPS.C									*
 *																				*
 *		Utility to convert assembly source code to all caps	*
 *																				*
 ************************************************************/

#include	<stdio.h>
#include	<ctype.h>

#define	comment	';'

FILE	*fpi;
FILE	*fpo;
char	bfr[256];

int main(int argc, char *argv[])
{
	int	i;

	if (argc < 3)
	{
		printf("\nUsage: srccaps file.in file.out\n");
		return(1);
	}
	fpi = fopen(argv[1], "rt");
	if (fpi == NULL)
	{
		printf("Can't open '%s'\n", argv[1]);
		return(1);
	}
	fpo = fopen(argv[2], "wt");
	if (fpi == NULL)
	{
		printf("Can't open '%s'\n", argv[2]);
		return(1);
	}
	while (fgets(bfr, 255, fpi))
	{
		i = 0;
		while (bfr[i])
		{
			if (bfr[i] == comment)
				break;
			if (islower(bfr[i]))
				bfr[i] = toupper(bfr[i]);
			i++;
		}
		fputs(bfr, fpo);
	}
	fclose(fpi);
	fclose(fpo);
	return(0);
}

/* end of srccaps.c */

