org 0000h					; jump to 7270 from 14ac
		L      A, ACC
                MOV    er0, A
                MOV    DP, #07A11h
                LC     A, [DP]
                MUL
                ROL    A
                L      A, er1
                ROL    A
                ST     A, off(00142h)
                JBS    off(0011fh).5, BITJUMP
                J      015bdh
BITJUMP:	J      01470h
