
/************************************************************************
 *																								*
 *		Z80 Disassembler - Copyright (C) 1996-2002 by							*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *		theposts@soca.com																	*
 *																								*
 *		DZ80.H - Header File																*
 *																								*
 *		Version 3.0 - 01/31/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

/***************************
 *									*
 *		Defined Constants		*
 *									*
 ***************************/

#define	MSDOS		/* Uncomment this for machines with segmented CPU
							architectures. For intelligently designed CPUs,
							we can use malloc instead of farmalloc for 64K
							byte arrays. */

/*#define	LINUX*/		/* Linux has no stricmp library function, must use
							strcasecmp instead. */

#define	VERNO		3
#define	REVNO		0

#ifndef	TRUE
#define	TRUE		1
#endif

#ifndef	FALSE
#define	FALSE		0
#endif

#define	byte		unsigned char
#define	word		unsigned short

#define	FN_LEN	128
#define	MAX_LINE	128

#define	TSTOP		32								/* tab stop */
#define	ASTOP		56								/* ascii stop */
#define	XSTOP		49								/* hex stop */

#define	PMEMSIZE	(65536L)						/* code space */

#define	EITHERFILE	0
#define	HEXFILE		1
#define	BINFILE		2

#define	GOOD_EXIT	0
#define	MEM_ERROR	1
#define	FILE_ERROR	2
#define	USER_ERROR	3

#define	SYMBOL		0
#define	LABEL			1

#define	ASCLINE		32		/* max length of ascii defb line		*/
#define	ASCLIMIT		512	/* size of ascii buffer					*/
#define	BYTELINE		8		/* max length of binary defb line	*/
#define	BYTELIMIT	512	/* size of byte binary buffer			*/
#define	WORDLINE		6		/* max length of defw line				*/
#define	WORDLIMIT	512	/* size of word binary buffer			*/
#define	NO_DATA		0xff	/* pgmmem uninitialized value			*/

/* opttbl bits: */

#define	OPT_XFER		0x80	/* unconditional transfer				*/
#define	OPT_SPEC		0x40	/* special codes (cd, dd, ed, fd)	*/
#define	OPT_REL		0x20	/* relative addressing					*/
#define	OPT_DIR		0x10	/* direct addressing (jp, call)		*/
#define	OPT_PAR		0x08	/* parenthesized address				*/
#define	OPT_IMM		0x04	/* immediate data							*/
#define	OPT_3			0x02	/* 3 byte instruction					*/
#define	OPT_2			0x01	/* 2 byte instruction					*/
#define	OPT_NONE		0x00	/* single byte, no options				*/

#define	OPT_SIZE				(OPT_2 | OPT_3)
#define	OPT_IMM2				(OPT_IMM | OPT_2)
#define	OPT_PAR2				(OPT_PAR | OPT_2)
#define	OPT_DIR_IMM3		(OPT_DIR | OPT_IMM | OPT_3)
#define	OPT_PAR_IMM3		(OPT_PAR | OPT_DIR_IMM3)
#define	OPT_REL2				(OPT_REL | OPT_2)
#define	OPT_SPEC2			(OPT_SPEC | OPT_2)

/* ED option bits: */

#define	OPT_ED_2			0x01	/* 2 byte, entry in edtbl				*/
#define	OPT_ED_STORE	0x03	/* write 16 bit register to memory	*/
#define	OPT_ED_LD_BC	0x13	/* load bc from memory					*/
#define	OPT_ED_LD_DE	0x23	/* load de from memory					*/
#define	OPT_ED_LD_SP	0x33	/* load sp from memory					*/
#define	OPT_ED_RET		0x81	/* retn or reti							*/

/* DD and FD option bits: */

#define	OPT_DD_2			0x01	/* 2 byte, entry in dd1tbl				*/
#define	OPT_DD_LOAD		0x02	/* 3 byte loads							*/
#define	OPT_DD_DIR		0x03	/* 4 byte direct addressing			*/
#define	OPT_DD_ARTH		0x06	/* 3 byte arithmetic codes				*/
#define	OPT_DD_CB		0x07	/* 4 byte dd/fd cb codes				*/

/* pgmflags bits: */

#define	PF_INIT		0xff	/* initial value					*/
#define	PF_DATA		0x00	/* data valid from file			*/
#define	PF_NOINIT	0x80	/* set if uninitialized space	*/
#define	PF_ADRS		0x40	/* address data					*/
#define	PF_WORD		0x20	/* word binary data				*/
#define	PF_BYTE		0x10	/* byte binary data				*/
#define	PF_CLREF		0x08	/* clear if referenced			*/
#define	PF_ASCII		0x04	/* ascii text						*/
#define	PF_SPLIT		0x02	/* set if split opcode			*/
#define	PF_REF		0x01	/* set if referenced				*/

/*********************************
 *											*
 *		Structure Definitions		*
 *											*
 *********************************/

/* symbol table and label table entries */

struct sym {
	struct sym	*next;
	word			val;
	byte			used;
	char			name[1];
};

typedef	struct sym *	SYM_PTR;

/* comment structure */

struct comment {
	word	adrs;
	char	*str;
	struct comment	*next;
};

typedef	struct comment *	COMMENT_PTR;

/* mnemonic table entries */

struct mnementry {
   char mcode[16];
};

struct snementry {
   char mcode[8];
};

struct entry {
	char mnem[16];
};

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

extern void	usage(void);
extern int	main(int argc, char *argv[]);
extern word	atox(char *str);

#ifdef	MSDOS
extern void	getcode(char *from, byte huge *loc);
#else
extern void	getcode(char *from, byte *loc);
#endif

extern void				add_entry(word val, char *symbol, int type);
extern char				*find_entry(word val, word count, SYM_PTR *table);
extern struct sym		*get_smem(int type, int size);
extern void				add_comment(word adrs, char *str);
extern void				output_comment(word adrs);

/***************************
 *									*
 *		Global Variables		*
 *									*
 ***************************/

extern char	src[FN_LEN], dst[FN_LEN];	/* file name buffers				*/
extern char	ctl[FN_LEN];					/* control file name				*/
extern char	alt_ctl[FN_LEN];				/* alternate control file name*/
extern char	linebuffer[128];				/* input line buffer				*/
extern FILE	*fp;								/* dos file struct				*/
extern int	hexflag;							/* append hex flag				*/
extern int	fileflag;						/* file type flag					*/
extern int	kcnt;								/* output char counter			*/
extern word	pc;								/* current program counter		*/
extern word	himark;							/* highest data adrs				*/
extern word	offset;							/* program counter offset		*/

#ifdef	MSDOS

extern byte	huge *pgmmem;					/* program data pointer			*/
extern byte	huge *pgmflags;				/* pointer to program flags	*/
extern byte	huge *cmtflags;				/* comment flags					*/

#else

extern byte	*pgmmem;							/* program data pointer			*/
extern byte	*pgmflags;						/* pointer to program flags	*/
extern byte	*cmtflags;						/* comment flags					*/

#endif

extern char	string[ASCLIMIT];				/* ascii data for defb			*/
extern word	asc_cnt;							/* count for string data		*/
extern byte	byte_data[BYTELIMIT];		/* binary data for defb			*/
extern word	byte_cnt;						/* count for binary data		*/
extern word	word_data[WORDLIMIT];		/* binary data for defw			*/
extern word	word_cnt;						/* count for word data			*/
extern byte	dump;								/* dump just done flag			*/
extern byte	ascii_flag;						/* use ascii string flag		*/
extern struct sym	*sym_tab;				/* symbol table pointer			*/
extern struct sym	*lab_tab;				/* label table pointer			*/
extern struct sym	*sym_tab_last;			/* last symbol table pointer	*/
extern struct sym	*lab_tab_last;			/* lastlabel table pointer		*/
extern char	defbstr[8];						/* string for defined bytes	*/
extern char	defwstr[8];						/* string for defined words	*/
extern char	ascistr[8];						/* string for defined ascii	*/
extern word	symbol_count;					/* number of symbols				*/
extern word	label_count;					/* number of labels				*/
extern struct comment *comment_list;

/* end of dz80.h */

