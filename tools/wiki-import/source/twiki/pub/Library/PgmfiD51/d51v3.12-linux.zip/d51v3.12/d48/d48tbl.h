
/************************************************************************
 *																								*
 *		D48 8048/41 Disassembler - Copyright (C) 1995-1999 by					*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *																								*
 *		D48TBL.H - Header File															*
 *																								*
 *		Version 2.1 - 10/29/99															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

/***************************
 *									*
 *		Global variables		*
 *									*
 ***************************/

extern byte				optbl[256];
extern byte				bctbl[256];
extern struct entry	mnemtbl[256];
extern struct regent	rbname[];

/* end of d48tbl.h */

