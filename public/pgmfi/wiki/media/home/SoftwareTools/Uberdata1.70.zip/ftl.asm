org 0000h

	LB	A, 0BBh
	CMPB	A, #07Fh
	JGE	bcut

	LB 	A, 0CCh
	CMPB 	A, #016h
	JGT	skip
	JBR 	off(0211h).2, skip

ftl:	L 	A, #0030dh
	ST	A, (00292h-00280h)[USP]
	L 	A, #002eeh
	ST	A, (00294h-00280h)[USP]
	J 	03FD0h
 
skip:	JBS	off(0210h).3, fts

reg:	L 	A, #001e0h
	ST	A, (00292h-00280h)[USP]
	L 	A, #001d4h
	ST	A, (00294h-00280h)[USP]
	J 	03FD0h

fts:	L 	A, #00227h
	ST	A, (00292h-00280h)[USP]
	L 	A, #00217h
	ST	A, (00294h-00280h)[USP]
	J 	03FD0h

bcut:	L 	A, #0030dh
	ST	A, (00292h-00280h)[USP]
	L 	A, #002eeh
	ST	A, (00294h-00280h)[USP]
	J 	03FD0h	
