;
; Control file directives to make Keil A51 happy.
;
; SFRs
;
f 84	84h	; adat
f 8e	8eh	; pwcm
f 8f	8fh	; pwmp
f a9	0a9h	; cml0
f aa	0aah	; cml1
f ab	0abh	; cml2
f ac	0ach	; ctl0
f ad	0adh	; ctl1
f ae	0aeh	; ctl2
f af	0afh	; ctl3
f c0	0c0h	; p4
f c4	0c4h	; p5
f c5	0c5h	; adcon
f c6	0c6h	; adch
f c8	0c8h	; t2con
f c9	0c9h	; cmh0
f ca	0cah	; rcap2l
f cb	0cbh	; rcap2h
f cc	0cch	; tl2
f cd	0cdh	; th2
f ce	0ceh	; cth2
f cf	0cfh	; cth3
f d8	0d8h	; i2cfg
f d9	0d9h	; s1sta
f da	0dah	; s2dat
f db	0dbh	; s1adr
f e8	0e8h	; csr
f ea	0eah	; tm2con
f eb	0ebh	; ctcon
f ec	0ech	; tml2
f ed	0edh	; tmh2
f ee	0eeh	; ste
f ef	0efh	; rte
f fc	0fch	; pwm0
f fd	0fdh	; pwm1
f fe	0feh	; pwena
f ff	0ffh	; t3
;
; SFR bits
;
k c8	0c8h.0	; cprl2
k c9	0c8h.1	; ct2
k ca	0c8h.2	; tr2
k cb	0c8h.3	; exen2
k cc	0c8h.4	; tclk
k cd	0c8h.5	; rclk
k ce	0c8h.6	; exf2
k cf	0c8h.7	; tf2
k d8	0d8h.0	; ct0
k d9	0d8h.1	; ct1
k da	0d8h.2	; i2cfg.2
k db	0d8h.3	; i2cfg.3
k dc	0d8h.4	; tirun
k dd	0d8h.5	; clrti
k de	0d8h.6	; mastrq
k df	0d8h.7	; slaven
k e8	0e8h.0	; ibf
k e9	0e8h.1	; obf
k ea	0e8h.2	; idsm
k eb	0e8h.3	; obfc
k ec	0e8h.4	; ma0
k ed	0e8h.5	; ma1
k ee	0e8h.6	; mb0
k ef	0e8h.7	; mb1
k f8	0f8h.0	; xstp
k f9	0f8h.1	; xstr
k fa	0f8h.2	; makstp
k fb	0f8h.3	; makstr
k fc	0f8h.4	; xactv
k fd	0f8h.5	; xdata
k fe	0f8h.6	; idle
k ff	0f8h.7	; i2sta.7
;

