org 0000h

int_serial_rx:  L       A, 0fah
                ST      A, IE
                MOV     PSW, #00102h
                MOV     LRB, #0007eh
                RB      off(00356h).6
                JEQ     label_6a14
                SJ      label_6a73

label_6a14:     CLR     A
                LB      A, SRBUF
                CMPB    r3, #000h
                JNE     label_6a29
                STB     A, r2
                INCB    r3
                CMPB    A, #010h
                JLT     label_6a73
                CMPB    A, #020h
                JLE     label_6a57
                SJ      label_6a73

label_6a29:     CMPB    r3, #001h
                JNE     label_6a33
                STB     A, r1
                INCB    r3
                SJ      label_6a73

label_6a33:     CMPB    r3, #002h
                JNE     label_6a45
                STB     A, r0
                INCB    r3
                CMPB    r2, #001h
                JNE     label_6a73
                MOV     DP, er0
                LB      A, [DP]
                SJ      label_6a6c

label_6a45:     CMPB    r2, #002h
                JNE     label_6a6a
                CMPB    r3, #003h
                JNE     label_6a6a
                MOV     DP, er0
                STB     A, [DP]
                LB      A, #0aah
                SJ      label_6a6c

label_6a57:     SUBB    A, #010h
                RC
                SLLB    A
                ANDB    A, #0ffh
                NOP
                MOV     DP, #lookuptable
		ADD	DP, #006a00h
                ADD     DP, A
                LC      A, [DP]
                MOV     DP, A
                LB      A, [DP]
                SJ      label_6a6c

label_6a6a:     LB      A, #055h

label_6a6c:     STB     A, STBUF
                SB      off(00356h).6
                CLRB    r3

label_6a73:     L       A, 0f8h
                ANDB    PSWH, #0feh
                ST      A, IE
                RTI

lookuptable:	dw	02D4h		; 10 - ECT - Working
		dw	03CCh		; 11 - IAT - Working
		dw	03CAh		; 12 - O2 - Working
		dw	03CDh		; 13 - PA Sensor - Working
		dw	03BBh		; 14 - MAP Sensor - Working
		dw	00A4h		; 15 - TPS Sensor - Working
		dw	03C4h		; 16 - RPM Low Byte - Working
		dw	00C5h		; 17 - RPM High Byte - Working
		dw	001Ch		; 18 - VTEC On/Off - Need to Find it
		dw	01E7h		; 19 - Low Cam Fuel/Ignition Y-Axis - Working
		dw	01E8h		; 1A - High Cam Fuel/Ignition Y-Axis - working
		dw	01DFh		; 1B - Low/High Cam Fuel/Ignition X-Axis - Working 
		dw	01EAh		; 1C - Low Cam Fuel/Ignition Y-Axis Interpolation Value - Working
		dw	01ECh		; 1D - High Cam Fuel/Ignition Y-Axis Interpolation Value - Working
		dw	01E2h		; 1E - Low/High Cam Fuel X-Axis Interpolation Value - Working
		dw	011Dh		; 1F - Not In Use
		dw	01CCh		; 20 - VSS - Working
