
/************************************************************************
 *																								*
 *		D51 8051/52 Disassembler - Copyright (C) 1995-2002 by					*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *		theposts@soca.com																	*
 *																								*
 *		D51P2.H - Header File															*
 *																								*
 *		Version 3.0 - 01/12/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

extern void	pass2(void);
extern void	pass3(void);
extern void	doopcode(char *mnem);
extern void	dodir(FILE *fp, word dir);
extern void	dobit(FILE *fp, word bit);
extern void	chk_ref(word i);
extern void	splitcheck(word i);
extern void	puthex(word j);
extern int	ascii(int i);
extern int	is_ascii(byte data);

/***************************
 *									*
 *		Global variables		*
 *									*
 ***************************/

extern int	newline;								/* just output newline flag	*/

#ifdef	MSDOS
extern struct date	date_data;				/* disassembly date				*/
extern struct time	time_data;				/* disassembly time				*/
#endif

#ifdef	LINUX
extern struct tm	*date_time;					/* disassembly time				*/
#endif

/* end of d51p2.h */

