; Thanks to a1kon, calvin, doc, pgmfi.org in general and anyone else who I've missed for making stuff like this possible.
org 0000h

ed_table:       DB  000h
speed_table:	DB  000h
rpm_table1:	DW  000eah
rpm_table2:	DW  000eah
rpm_table3:	DW  000eah
rpm_table4:	DW  000eah

check:	        JLT	unset_cel
                LCB	A, ed_table
                MB	C, ACC.0
                JGE	set_cel 		; Jump if not enable

		LB	A, 0cch			; Load VSS
		CMPB	A, #001h		; Check 1st speed
		JLT	FirstSpeed		; 
		CMPB	A, #002h		; Check 2nd speed
		JLT	SecondSpeed		; 
		CMPB	A, #003h		; Check 3rd speed
		JLT	ThirdSpeed		; 

FourthSpeed:
                LC	A, rpm_table4
		SJ	CheckRPM
ThirdSpeed:
                LC	A, rpm_table3
		SJ	CheckRPM
SecondSpeed:
                LC	A, rpm_table2
		SJ	CheckRPM
FirstSpeed:
                LC	A, rpm_table1

CheckRPM:
                CMP	0C4h, A			; Check with current RPM
                JLE	unset_cel

set_cel:	RB	P1.4
                J	04294h

unset_cel:	SB	P1.4
                J	04294h


