                CLR     A                      ; 4EA6 1 02 00 F9
                LB      A, r2                  ; 4EA7 0 02 00 7A		A = X
		L	A, ACC
                ADD     X1, A
                ADD     X1, A                  ; 4EA8 0 02 00 9081		X1 = Table + X
                LB      A, r3                  ; 4EBC 0 02 00 7B		A = Y
                MULB                           ; 4EBD 0 02 00 A234		A = Y * Table Width
		L	A, ACC
                ADD     X1, A
                ADD     X1, A                  ; 4EBF 0 02 00 9081		X1 = (Table + X) + (Y * Table Width) ; First value
                LC      A, [X1]                ; 4EC1 0 02 00 90A8
                MOV     ER1, A                 ; 4EC3 0 02 00 52

		LC      A, 002[X1]
                MOV     DP, A

                CLR     A                      ; 4EC4 1 02 00 F9
                LB      A, r0                  ; 4EC5 0 02 00 78		A = Table Width
		L	A, ACC
                ADD     X1, A
                ADD     X1, A                  ; 4EC6 0 02 00 9081		X1 = (Table + X) + (Y * Table Width) + Table Width; Second value set
                LC      A, 002[X1]             ; 4EC8 0 02 00 90A8
                MOV     ER2, A                 ; 4ECA 0 02 00 50		X1 = (0,1) & (1,1)
                LC      A, [X1]



                MOV     X1, er1                ; 4EE2 1 02 00 4578		X1 = FINAL(0,0)
                XCHG    A, er2                 ; 4EE4 1 02 00 4610		ER2 = FINAL(0,1) ; A = FINAL(1,1)




                MOV     er0, X2                ; 4EE6 1 02 00 9148
                SCAL    label_4ef5             ; 4EE8 1 02 00 32F54E
                MOV     er2, X1                ; 4EEB 1 02 00 904A
                MOV     X1, A                  ; 4EED 1 02 00 50
                L       A, DP                  ; 4EEE 1 02 00 42
                SCAL    label_4ef5             ; 4EEF 1 02 00 32F54E
                L       A, X1                  ; 4EF2 1 02 00 40
                MOV     er0, er3               ; 4EF3 1 02 00 4748
                                               ; 4EF5 from 4F12 (DD1,P02,B00)
                                               ; 4EF5 from 4EE8 (DD1,P02,B00)
                                               ; 4EF5 from 4EEF (DD1,P02,B00)
label_4ef5:     SUB     A, er2                 ; 4EF5 1 02 00 2A
                JGE     label_4f02             ; 4EF6 1 02 00 CD0A
                ST      A, er1                 ; 4EF8 1 02 00 89
                CLR     A                      ; 4EF9 1 02 00 F9
                SUB     A, er1                 ; 4EFA 1 02 00 29
                MUL                            ; 4EFB 1 02 00 9035
                L       A, er1                 ; 4EFD 1 02 00 35
                SUB     er2, A                 ; 4EFE 1 02 00 46A1
                L       A, er2                 ; 4F00 1 02 00 36
                RT                             ; 4F01 1 02 00 01
                                               ; 4F02 from 4EF6 (DD1,P02,B00)
label_4f02:     MUL                            ; 4F02 1 02 00 9035
                L       A, er1                 ; 4F04 1 02 00 35
                ADD     A, er2                 ; 4F05 1 02 00 0A
                ST      A, er2                 ; 4F06 1 02 00 8A
                RT                             ; 4F07 1 02 00 01
