
/************************************************************************
 *																								*
 *		D48 8048/41 Disassembler - Copyright (C) 1995-2002 by					*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *		theposts@soca.com																	*
 *																								*
 *		D48.H - Header File																*
 *																								*
 *		Version 3.0 - 01/25/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

#define	MSDOS		/* Uncomment this for machines with segmented CPU
							architectures. For intelligently designed CPUs,
							we can use malloc instead of farmalloc for 64K
							byte arrays. */

/*#define	LINUX*/		/* Linux has no stricmp library function, must use
							strcasecmp instead. */

#define	VERNO		3
#define	REVNO		0

#define	byte		unsigned char
#define	word		unsigned short

#define	FN_LEN	128
#define	MAX_LINE	128

#define	PSIZE			4096
#define	ASTOP			56								/* ascii stop */
#define	TSTOP			16
#define	XSTOP			49

#define	EITHERFILE	0
#define	HEXFILE		1
#define	BINFILE		2

#define	GOOD_EXIT	0
#define	MEM_ERROR	1
#define	FILE_ERROR	2
#define	USER_ERROR	3

#define	SYMBOL		0
#define	LABEL			1

#define	ASCLINE		32		/* max length of ascii defb line		*/
#define	ASCLIMIT		512	/* size of ascii buffer					*/
#define	BYTELINE		8		/* max length of binary defb line	*/
#define	BYTELIMIT	512	/* size of byte binary buffer			*/
#define	WORDLINE		6		/* max length of defw line				*/
#define	WORDLIMIT	512	/* size of word binary buffer			*/
#define	NO_DATA		0xff	/* pmem uninitialized value			*/

/* pflag bits: */

#define	PF_INIT		0xff	/* initial value					*/
#define	PF_DATA		0x00	/* data valid from file			*/
#define	PF_NOINIT	0x80	/* set if uninitialized space	*/
#define	PF_ADRS		0x40	/* address data					*/
#define	PF_WORD		0x20	/* word binary data				*/
#define	PF_BYTE		0x10	/* byte binary data				*/
#define	PF_CLREF		0x08	/* clear if referenced			*/
#define	PF_ASCII		0x04	/* ascii text						*/
#define	PF_SPLIT		0x02	/* set if split opcode			*/
#define	PF_REF		0x01	/* set if referenced				*/

/* option table values: */

#define	OPT_XFER		0x80	/* unconditional transfer		*/
#define	OPT_INVAL	0x04	/* invalid opcode					*/
#define	OPT_EXT		0x03	/* extended memory reference	*/
#define	OPT_PAGE		0x02	/* memory ref in current page	*/
#define	OPT_IMM		0x01	/* immediate data					*/
#define	OPT_NONE		0x00	/* single byte, no options		*/

/*********************************
 *											*
 *		Structure Definitions		*
 *											*
 *********************************/

struct entry {
	char mnem[16];
};

/* symbol table and label table entries */

struct sym {
	struct sym	*next;
	word			val;
	byte			used;
	char			name[1];
};

typedef	struct sym *	SYM_PTR;

/* comment structure */

struct comment {
	word	adrs;
	char	*str;
	struct comment	*next;
};

typedef	struct comment *	COMMENT_PTR;

/* register name entries */

struct regent {
   char dent[8];
};

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

void	usage(void);
int	main(int argc, char *argv[]);
void	pass0(void);
void	error(char *str1, char *str2);
void	add_entry(word val, char *symbol, int type);
char	*find_entry(word val, word count, SYM_PTR *table);
struct sym	*get_smem(int type, int size);

struct sym	*sort(struct sym *list, SYM_PTR *array, word count);
struct sym	*sort_by_name(struct sym *list);
struct sym	*sort_by_value(struct sym *list);
struct sym	*merge_by_name(struct sym *a, struct sym *b);
struct sym	*merge_by_value(struct sym *a, struct sym *b);
void	chk_dup_name(struct sym *list, word count);
void	chk_dup_value(struct sym *list, word count);

char	*get_adrs(char *text, word *val);

/***************************
 *									*
 *		Global variables		*
 *									*
 ***************************/

extern char	src[FN_LEN], dst[FN_LEN];	/* file name buffers				*/
extern char	ctl[FN_LEN];					/* control file name				*/
extern char	linebuffer[128];				/* input line buffer				*/
extern FILE	*fp;								/* source file						*/
extern byte	hexflag;							/* append hex flag				*/
extern byte	fileflag;						/* file type flag					*/
extern byte	flag41;							/* 8041 flag						*/
extern int	kcnt;								/* output char counter			*/
extern byte	pdata[PSIZE];					/* program data space			*/
extern byte	pflag[PSIZE];					/* program flag space			*/
extern byte	cflag[PSIZE];					/* comment flags					*/
extern char	string[ASCLIMIT];				/* ascii output buffer			*/
extern int	asc_cnt;							/* count for ascii data			*/
extern byte	byte_data[BYTELIMIT];		/* binary data for defb			*/
extern int	byte_cnt;						/* count for binary data		*/
extern int	dump;								/* dump just done flag			*/
extern struct sym	*sym_tab;				/* symbol table pointer			*/
extern struct sym	*lab_tab;				/* label table pointer			*/
extern struct sym	*sym_tab_last;			/* last symbol table pointer	*/
extern struct sym	*lab_tab_last;			/* lastlabel table pointer		*/
extern word	symbol_count;					/* number of symbols				*/
extern word	label_count;					/* number of labels				*/
extern char	defbstr[8];
extern char	defwstr[8];

extern SYM_PTR	*sym_val_index;				/* array of pointers				*/
extern SYM_PTR	*lab_val_index;				/*  for binary search			*/
extern struct sym	*tail_ptr, *head_ptr;	/* sort pointers					*/

extern struct comment *comment_list;

/* end of d48.h */

