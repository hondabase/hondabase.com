
/************************************************************************
 *																								*
 *		D51 8051/52 Disassembler - Copyright (C) 1995-2002 by					*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *		theposts@soca.com																	*
 *																								*
 *		D51P1.H - Header File															*
 *																								*
 *		Version 3.0 - 01/12/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

#ifndef _D51P1_H_
#define _D51P1_H_

/*********************
 *							*
 *		Prototypes		*
 *							*
 *********************/

extern void	pass0(void);
extern void	pass1(void);
extern char	*get_adrs(char *text, word *val);
extern void	dump_ascii(word adrs);
extern void	dump_bytes(word adrs);
extern struct sym	*sort(struct sym *list, SYM_PTR *array, word count);
extern struct sym	*sort_by_name(struct sym *list);
extern struct sym	*sort_by_value(struct sym *list);
extern struct sym	*merge_by_name(struct sym *a, struct sym *b);
extern struct sym	*merge_by_value(struct sym *a, struct sym *b);
extern void	chk_dup_name(struct sym *list, word count);
extern void	chk_dup_value(struct sym *list, word count);
extern void	do_widget(void);

/***************************
 *									*
 *		Global variables		*
 *									*
 ***************************/

extern char	widget;
extern word	widget_count;

extern SYM_PTR	*sym_val_index;				/* array of pointers				*/
extern SYM_PTR	*lab_val_index;				/*  for binary search			*/
extern struct sym	*tail_ptr, *head_ptr;	/* sort pointers					*/

/* end of d51p1.h */

#endif