
/************************************************************************
 *																								*
 *		Z80 Disassembler - Copyright (C) 1996-2002 by							*
 *		Jeffery L. Post																	*
 *		22726 Benner Ave.																	*
 *		Torrance, CA  90505																*
 *																								*
 *		DZ80P2.C - Disassembly Passes 2 & 3											*
 *																								*
 *		Version 3.0 - 01/31/02															*
 *																								*
 *	This program is free software; you can redistribute it and/or modify	*
 *	it under the terms of the GNU General Public License as published by	*
 *	the Free Software Foundation; either version 2 of the License, or		*
 *	(at your option) any later version.												*
 *																								*
 *	This program is distributed in the hope that it will be useful,		*
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
 *	GNU General Public License for more details.									*
 *																								*
 *	You should have received a copy of the GNU General Public License		*
 *	along with this program; if not, write to the Free Software				*
 *	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.				*
 *																								*
 ************************************************************************/

#include	<stdio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<string.h>

#include	"dz80.h"
#include	"dz80p1.h"
#include	"dz80p2.h"
#include	"dz80tbl.h"

#ifdef	MSDOS
#include	<dos.h>
#endif

#ifdef	LINUX
#include	<time.h>
#endif

int	newline;								/* just output newline flag	*/

#ifdef	MSDOS
struct date	date_data;					/* disassembly date				*/
struct time	time_data;					/* disassembly time				*/
#endif

#ifdef	LINUX
struct tm	*date_time;					/* disassembly time				*/
#endif

int	opcount;								/* bytes/opcode count			*/

/*********************
 *							*
 *			Code			*
 *							*
 *********************/

/************************************************************************

	Pass two of disassembly. Rescan data array and generate output file.
	Generate label if location flagged as referenced by some other opcode.
	If un-initialized data is encountered, ignore it but set skip flag so
	that an ORG statement can be generated when the next initialized data
	is found.

************************************************************************/

void pass2(void)
{
	char	c, *cptr;
	int	skip;
	word	i, l, q, temp;
	byte	j, k, pflag;
	COMMENT_PTR	cmt;

#ifdef	LINUX
	time_t	tp;
#endif

	k = 0;
	j = 0xff;
	skip = 1;
	dump = 0;
	byte_cnt = 0;
	asc_cnt = 0;
	newline = 0;

	printf("\nPass 2 0000");

	if ((fp = fopen(dst, "w")) == NULL)			/* open output source file */
	{
		printf("\n* Can't open file %s *\n", dst);
		exit(FILE_ERROR);
	}
	fprintf(fp, ";\n;  Z80 Disassembly of %s", src);	/* output header */

#ifdef	MSDOS
	getdate(&date_data);
	gettime(&time_data);
	fprintf(fp, "\n;  %d/%d/%d %d:%02d", date_data.da_mon, date_data.da_day,
		date_data.da_year, time_data.ti_hour, time_data.ti_min);
#endif

#ifdef	LINUX
	time(&tp);									/* get current time */
	date_time = localtime(&tp);			/* convert to hr/min/day etc */
	fprintf(fp, "\n;  %d/%d/%d %d:%02d", date_time->tm_mon + 1,
		date_time->tm_mday, date_time->tm_year,
		date_time->tm_hour, date_time->tm_min);
#endif

/*  Generate output file */

	for (i=offset; i<himark; )
	{
		if (cmtflags[i])
		{
			if (byte_cnt)							/* dump any pending binary */
				dump_bytes(i);
			if (asc_cnt)							/* dump any accumulated ascii */
				dump_ascii(i);
			cmt = comment_list;
			while (cmt)
			{
				if (cmt->adrs == i)
					fprintf(fp, "\n%s", cmt->str);
				cmt = cmt->next;
			}
		}

		l = i & 0xff;
		pflag = pgmflags[i];
		if (pflag == PF_INIT)					/* ignore un-initialized data */
		{
			if (byte_cnt)				/* if binary or ascii data in buffers... */
				dump_bytes(i);			/* output them now */
			if (asc_cnt)
				dump_ascii(i);
			if (dump)					/* if we had to flush buffers...	*/
			{								/* do a newline, since we will	*/
				dump = 0;				/* be doing an org (or end)		*/
				fprintf(fp, "\n;");
				newline++;
			}
			i++;										/* next program location */
			skip = 1;								/* flag skip for ORG statement */
			j = -1;
		}
		else if (pflag & (PF_ADRS | PF_WORD | PF_BYTE | PF_ASCII))
		{												/* if not executable code */
			if (!(j & 0x80) && !skip)
			{
				j = -1;
				fprintf(fp, "\n;");
				newline++;
			}
			switch (pflag & ~PF_REF)			/* ignore reference bit */
			{
				case PF_ASCII:						/* if ascii text... */
					if (byte_cnt)					/* dump any pending binary */
						dump_bytes(i);
					if (skip)						/* insert ORG statement */
					{
						if (!newline)
							fprintf(fp, "\n;");
						fprintf(fp, "\n\torg\t");
						puthex(i);
						fprintf(fp, "\n;");
						newline++;
						skip = 0;					/* reset skip flag */
					}
					if (is_ascii(pgmmem[i]))	/* if it really is ascii... */
					{
						string[asc_cnt] = pgmmem[i];
						asc_cnt++;
						if (asc_cnt >= ASCLIMIT)
							dump_ascii(i + 1);
					}
					else								/* else treat it as binary data */
					{
						pgmflags[i] |= PF_BYTE;
						if (asc_cnt)				/* dump any accumulated ascii */
							dump_ascii(i);
						byte_data[byte_cnt] = pgmmem[i];	/* add data to buffer */
						byte_cnt++;
					}
					break;

				case PF_WORD:					/* if word data... */
					if (byte_cnt)			/* dump any binary or ascii in buffers */
						dump_bytes(i);
					if (asc_cnt)
						dump_ascii(i);
					if (skip)					/* insert ORG statement */
					{
						if (!newline)
							fprintf(fp, "\n;");
						fprintf(fp, "\n\torg\t");
						puthex(i);
						fprintf(fp, "\n;");
						newline++;
						skip = 0;				/* reset skip flag */
					}
					chk_ref(i);							/* add label if referenced */
					q = ((word) pgmmem[i + 1]) << 8;	/* get word value */
					temp = pgmmem[i] & 0xff;
					q |= temp;
					fprintf(fp, "%s\t", defwstr);
					cptr = find_entry(q, symbol_count, sym_val_index);	/* see if symbol exists */
					if (cptr == NULL)						/* if not, do hex value */
						puthex(q);
					else
						fprintf(fp, "%s", cptr);		/* else output symbol */
					if (hexflag)							/* add comment field */
					{
						fprintf(fp, "\t\t; %04x   %02x %02x      %c%c",
							i, pgmmem[i], pgmmem[i + 1],
							ascii(pgmmem[i]), ascii(pgmmem[i + 1]));
					}
					i++;
					if (pgmflags[i + 2] != PF_ADRS && pgmflags[i + 2] != PF_WORD)
					{
						fprintf(fp, "\n;");
						newline++;
					}
					break;

				case PF_ADRS:					/* if address data... */
					if (byte_cnt)				/* output any pending binary or */
						dump_bytes(i);			/* ascii data from buffers */
					if (asc_cnt)
						dump_ascii(i);
					if (skip)					/* insert ORG statement */
					{
						if (!newline)
							fprintf(fp, "\n;");
						fprintf(fp, "\n\torg\t");
						puthex(i);
						fprintf(fp, "\n;");
						newline++;
						skip = 0;				/* reset skip flag */
					}
					chk_ref(i);					/* add label if referenced */
					q = ((word) pgmmem[i + 1]) << 8;	/* get address value */
					temp = pgmmem[i] & 0xff;
					q |= temp;
					fprintf(fp, "%s\t", defwstr);
					cptr = find_entry(q, label_count, lab_val_index);	/* see if label exists */
					if (cptr == NULL)						/* if not, output hex */
					{
						cptr = find_entry(q, symbol_count, sym_val_index);
						if (cptr == NULL)
							fprintf(fp, "X%04x", q);
						else
							fprintf(fp, "%s", cptr);
					}
					else
						fprintf(fp, "%s", cptr);		/* else output label text */
					if (hexflag)							/* do comment field */
					{
						fprintf(fp, "\t\t; %04x   %02x %02x      %c%c",
							i, pgmmem[i], pgmmem[i + 1],
							ascii(pgmmem[i]), ascii(pgmmem[i + 1]));
					}
					i++;
					if (pgmflags[i + 2] != PF_ADRS)
					{
						fprintf(fp, "\n;");
						newline++;
					}
					break;

				default:							/* default = binary data... */
					if (asc_cnt)				/* output any pending ascii data */
						dump_ascii(i);
					if (skip)					/* insert ORG statement */
					{
						if (!newline)
							fprintf(fp, "\n;");
						fprintf(fp, "\n\torg\t");
						puthex(i);
						fprintf(fp, "\n;");
						newline++;
						skip = 0;				/* reset skip flag */
					}
					byte_data[byte_cnt] = pgmmem[i];	/* add data to buffer */
					byte_cnt++;
					if (byte_cnt >= BYTELIMIT)			/* if end of buffer...	*/
						dump_bytes(i + 1);				/* dump accumulated data */
			}
			i++;									/* next program location */
			if (pgmflags[i] != PF_INIT && pgmflags[i] & PF_ASCII)
			{										/* if next byte is flagged as	*/
				if (!is_ascii(pgmmem[i]))	/* ascii, but is not...			*/
					pgmflags[i] |= PF_BYTE;	/* then flag it as binary		*/
			}
		}

/*	If previous data was an unconditional transfer, AND current
	location is not referenced by some other opcode, AND current
	byte is 0 or 0FFH, then treat this byte as un-initialized data.
*/

		else if ((j & 0x10) && (!(pflag & PF_REF)) &&
				((pgmmem[i] == 0) || (pgmmem[i] == NO_DATA)))
		{
			if (byte_cnt)				/* since we're going to skip some */
				dump_bytes(i);			/* data, output any pending ascii */
			if (asc_cnt)				/* or binary data remaining in buffers */
				dump_ascii(i);
			if (dump)					/* if ascii or binary output was done, */
			{								/* stick in a newline */
				fprintf(fp, "\n;");
				dump = 0;
				newline++;
			}
			pgmflags[i] = PF_INIT;	/* flag as uninitialized data */
			i++;
			skip = 1;
			byte_cnt = 0;
		}

/* If previous opcode was 0 or 0ffH, AND current location is not
	referenced but is initialized, AND current opcode is 0 or 0ffH,
	un-initialize it.
*/

		else if ((k == 0 || k == 0xff) &&
			(!(pflag & PF_REF)) && (pgmmem[i] == 0 || pgmmem[i] == 0xff) &&
			(!(pflag & PF_CLREF)) && !(pflag & PF_NOINIT))
		{
			pgmflags[i] = '\xff';
			i++;
			skip = 1;
			fprintf(fp, "\t; data truncated");
			j = -1;
		}

		else								/**** IT'S EXECUTABLE CODE! ****/
		{
			pgmflags[i] &= ~PF_NOINIT;	/* clear for label search in pass 3 */
			if (byte_cnt)				/* if any ascii or binary data remains */
				dump_bytes(i);			/* in the buffers, output them now */
			if (asc_cnt)
				dump_ascii(i);
			if (dump)
			{
				fprintf(fp, "\n;");
				dump = 0;
				newline++;
			}
			byte_cnt = 0;
			if (skip)						/* insert ORG statement */
			{
				if (!newline)
					fprintf(fp, "\n;");
				fprintf(fp, "\n\torg\t");
				puthex(i);
				fprintf(fp, "\n;");
				newline++;
				skip = 0;					/* reset skip flag */
			}
			chk_ref(i);							/* add label if referenced */
			kcnt = 8;
			opcount = 1;
			k = pgmmem[i];						/* get opcode */
			j = opttbl[k];						/* get options */
			doopcode(mnemtbl[k].mcode);	/* output mnemonic */

	/* Generate operands */

			switch (j & ~OPT_XFER)
			{
					/* single byte - no options */

				case OPT_NONE:
					break;

					/* 2 byte immediate data */

				case OPT_IMM2:
					q = (word) pgmmem[i + 1] & 0xff;
					cptr = find_entry(q, symbol_count, sym_val_index);
					if (cptr == NULL)
						puthex(pgmmem[i + 1]);
					else
						kcnt += fprintf(fp, "%s", cptr);
					splitcheck(i + 1);
					break;

					/* 2 byte parenthesized address (in, out) */

				case OPT_PAR2:
					fprintf(fp, "(");
					kcnt++;
					q = (word) pgmmem[i + 1] & 0xff;
					cptr = find_entry(q, symbol_count, sym_val_index);
					if (cptr == NULL)
						puthex(pgmmem[i + 1]);
					else
						kcnt += fprintf(fp, "%s", cptr);
					fprintf(fp, ")");
					kcnt++;
					if (!(k & 8))				/* if out (n),a */
					{
						fprintf(fp, ",a");
						kcnt += 2;
					}
					splitcheck(i+1);
					break;

					/* 3 byte immediate data */

				case OPT_DIR_IMM3:
					q = (pgmmem[i + 2] << 8) | pgmmem[i + 1];
					cptr = find_entry(q, label_count, lab_val_index);
					if (cptr == NULL)
						kcnt += fprintf(fp, "X%04x", q);
					else
						kcnt += fprintf(fp, "%s", cptr);
					splitcheck(i+1);
					splitcheck(i+2);
					break;

					/* 3 byte parenthesized address, immediate data */

				case OPT_PAR_IMM3:
					q = (pgmmem[i + 2] << 8) | pgmmem[i + 1];
					cptr = find_entry(q, label_count, lab_val_index);
					if (cptr == NULL)
						kcnt += fprintf(fp, "(X%04x", q);
					else
						kcnt += fprintf(fp, "(%s", cptr);
					switch (k)
					{
						case 0x22:
							kcnt += fprintf(fp, "),hl");
							break;

						case 0x2a:
						case 0x3a:
							kcnt += fprintf(fp, ")");
							break;

						case 0x32:
							kcnt += fprintf(fp, "),a");
							break;
					}
					splitcheck(i+1);
					splitcheck(i+2);
					break;

					/* 2 byte relative addressing */

				case OPT_REL2:
					q = pgmmem[i + 1] & 0xff;
					q = (q > 0x7f) ? q | 0xff00 : q;
					q = i + 2 + q;
					cptr = find_entry(q, label_count, lab_val_index);
					if (cptr == NULL)
						kcnt += fprintf(fp, "X%04x", q);
					else
						kcnt += fprintf(fp, "%s", cptr);
					splitcheck(i+1);
					break;

					/* special processing codes (dd, ed, fd) */

				case OPT_SPEC:
					opcount = 2;
					switch (k)
					{
						case 0xed:
							k = pgmmem[i + 1];		/* get 2nd byte */
							if (edcode[k])
							{
								c = (k < 0xa0) ? k - 0x40 : k - 0x64;
								doopcode(edtbl[c].mcode);
								switch (edcode[k])
								{
									case OPT_ED_2:
										break;

									case OPT_ED_STORE:
										q = (pgmmem[i + 3] << 8) | pgmmem[i + 2];
										cptr = find_entry(q, label_count, lab_val_index);
										if (cptr == NULL)
											kcnt += fprintf(fp, "(X%04x)", q);
										else
											kcnt += fprintf(fp, "(%s)", cptr);
										opcount = 4;
										break;

									case OPT_ED_LD_BC:
										q = (pgmmem[i + 3] << 8) | pgmmem[i + 2];
										cptr = find_entry(q, label_count, lab_val_index);
										if (cptr == NULL)
											kcnt += fprintf(fp, "(X%04x)", q);
										else
											kcnt += fprintf(fp, "(%s)", cptr);
										kcnt += fprintf(fp, ",bc");
										opcount = 4;
										break;

									case OPT_ED_LD_DE:
										q = (pgmmem[i + 3] << 8) | pgmmem[i + 2];
										cptr = find_entry(q, label_count, lab_val_index);
										if (cptr == NULL)
											kcnt += fprintf(fp, "(X%04x)", q);
										else
											kcnt += fprintf(fp, "(%s)", cptr);
										kcnt += fprintf(fp, ",de");
										opcount = 4;
										break;

									case OPT_ED_LD_SP:
										q = (pgmmem[i + 3] << 8) | pgmmem[i + 2];
										cptr = find_entry(q, label_count, lab_val_index);
										if (cptr == NULL)
											kcnt += fprintf(fp, "(X%04x)", q);
										else
											kcnt += fprintf(fp, "(%s)", cptr);
										kcnt += fprintf(fp, ",sp");
										opcount = 4;
										break;

									case OPT_ED_RET:		/* retn or reti */
										j |= 0x80;
										break;
								}
							}
							else
							{
								invalided(k);
								j |= 0x80;
							}
							break;

						case 0xdd:
							j |= doindex(i, 'x');
							break;

						case 0xfd:
							j |= doindex(i, 'y');
							break;
					}
					break;

					/* cb special codes */

				case OPT_SPEC2:
					c = pgmmem[i + 1];
					temp = (word) (c >> 3) & 0x1f;
					if (*cbtbl[temp].mcode == '\0')
					{
						doopcode(defbstr);
						putc('\t', fp);
						kcnt = (kcnt + 8) & 0x78;
						puthex(0xcb);
						putc(',', fp);
						kcnt++;
						puthex(c);
						j |= 0x80;
					}
					else
					{
						doopcode(cbtbl[temp].mcode);
						doopcode(regtbl[c & 7].mcode);
					}
					break;
			}

			if (hexflag)				/* do comment field */
			{
				while (kcnt < TSTOP)
				{
					fprintf(fp, "\t");
					kcnt = (kcnt + 8) & 0x78;
				}
				
				kcnt += fprintf(fp, "; %04x ", i);
				q = (opttbl[k] & OPT_SIZE) + opcount;
				for (c=0; c<q; c++)
					kcnt += fprintf(fp, " %02x", pgmmem[i + c]);
				do
				{
					putc('\t', fp);
					kcnt = (kcnt + 8) & 0x78;
				} while (kcnt < ASTOP);

				for (c=0; c<q; c++)
					putc(ascii(pgmmem[i + c]), fp);
			}
			newline = 0;
			if (j & OPT_XFER)				/* if unconditional transfer */
			{
				fprintf(fp, "\n;");		/* or invalid opcode */
				newline++;
			}
			i = i + (opttbl[k] & OPT_SIZE) + opcount;	/* update location counter */
		}
		if ((i & 0xff) < l)
			printf("\rPass 2 %04x", i & 0xff00);
	}
	if (byte_cnt)					/* if any remaining ascii or binary, */
		dump_bytes(i);				/* output it now */
	if (asc_cnt)
		dump_ascii(i);
	printf("\rPass 2 - Source generation complete");
}												/*  End of Pass 2 */

void invalided(byte k)
{
	doopcode(defbstr);
	putc('\t', fp);
	kcnt = (kcnt + 8) & 0x78;
	puthex(0xed);
	putc(',', fp);
	kcnt++;
	puthex(k);
}

word doindex(word i, char index)
{
	byte			j, k;
	word			q, v;
	char			*cptr;

	j = pgmmem[i + 1];			/* get second byte */
	k = ddcode[j];					/* get flags */
	if (!k)
	{
		doopcode(defbstr);
		putc('\t', fp);
		kcnt = (kcnt + 8) & 0x78;
		index = (index == 'x') ? 0xdd : 0xfd;
		puthex(index);
		putc(',', fp);
		kcnt++;
		puthex(j);
		opcount = 2;
		return (0x80);
	}
	j = k >> 4;
	switch (k & 0xf)
	{
		case OPT_DD_2:
			doopcode(dd1tbl[j].mcode);
			q = 0;
			switch (j)
			{
				case 0:
					kcnt += fprintf(fp, "i%c,bc", index);
					break;

				case 1:
					kcnt += fprintf(fp, "i%c,de", index);
					break;

				case 2:
				case 4:
				case 6:
				case 8:
				case 7:
				case 10:
					kcnt += fprintf(fp, "i%c", index);
					break;

				case 9:
					kcnt += fprintf(fp, "i%c)", index);
					q = 0x80;
					break;

				case 3:
					kcnt += fprintf(fp, "i%c,i%c", index, index);
					break;

				case 5:
					kcnt += fprintf(fp, "i%c,sp", index);
					break;

				default:
					break;
			}
			opcount = 2;
			return(q);

		case OPT_DD_LOAD:
			switch (j)
			{
				case 0:
					doopcode("inc (i");
					kcnt += fprintf(fp, "%c+", index);
					v = (word) pgmmem[i + 2] & 0xff;
					cptr = find_entry(v, symbol_count, sym_val_index);
					if (cptr == NULL)
						puthex(v);
					else
						kcnt += fprintf(fp, "%s", cptr);
					putc(')', fp);
					kcnt++;
					break;

				case 1:
					doopcode("dec (i");
					kcnt += fprintf(fp, "%c+", index);
					v = (word) pgmmem[i + 2] & 0xff;
					cptr = find_entry(v, symbol_count, sym_val_index);
					if (cptr == NULL)
						puthex(v);
					else
						kcnt += fprintf(fp, "%s", cptr);
					putc(')', fp);
					kcnt++;
					break;

				case 2:
					indxld1(i, 'b', index);
					break;

				case 3:
					indxld1(i, 'c', index);
					break;

				case 4:
					indxld1(i, 'd', index);
					break;

				case 5:
					indxld1(i, 'e', index);
					break;

				case 6:
					indxld1(i, 'h', index);
					break;

				case 7:
					indxld1(i, 'l', index);
					break;

				case 8:
					indxld2(i, 'b', index);
					break;

				case 9:
					indxld2(i, 'c', index);
					break;

				case 10:
					indxld2(i, 'd', index);
					break;

				case 11:
					indxld2(i, 'e', index);
					break;

				case 12:
					indxld2(i, 'h', index);
					break;

				case 13:
					indxld2(i, 'l', index);
					break;

				case 14:
					indxld2(i, 'a', index);
					break;

				case 15:
					indxld1(i, 'a', index);
					break;
			}
			opcount = 3;
			return(0);

		case OPT_DD_DIR:
			doopcode("ld ");
			q = (pgmmem[i + 2] & 0xff) | ((pgmmem[i + 3] << 8) & 0xff00);
			switch (j)
			{
				case 0:
					cptr = find_entry(q, label_count, lab_val_index);
					if (cptr == NULL)
						kcnt += fprintf(fp, "i%c,X%04x", index, q);
					else
						kcnt += fprintf(fp, "i%c,%s", index, cptr);
					break;

				case 1:
					cptr = find_entry(q, label_count, lab_val_index);
					if (cptr == NULL)
						kcnt += fprintf(fp, "(X%04x),i%c", q, index);
					else
						kcnt += fprintf(fp, "(%s),i%c", cptr, index);
					break;

				case 2:
					cptr = find_entry(q, label_count, lab_val_index);
					if (cptr == NULL)
						kcnt += fprintf(fp, "i%c,(X%04x)", index, q);
					else
						kcnt += fprintf(fp, "i%c,(%s)", index, cptr);
					break;

				case 3:
					kcnt += fprintf(fp, "(i%c+", index);
					v = (word) pgmmem[i + 2] & 0xff;
					cptr = find_entry(v, symbol_count, sym_val_index);
					if (cptr == NULL)
						puthex(v);
					else
						kcnt += fprintf(fp, "%s", cptr);
					kcnt += fprintf(fp,"),");
					v = (word) pgmmem[i + 3] & 0xff;
					cptr = find_entry(v, symbol_count, sym_val_index);
					if (cptr == NULL)
						puthex(v);
					else
						kcnt += fprintf(fp, "%s", cptr);
					break;
			}
			opcount = 4;
			return(0);

		case OPT_DD_ARTH:
			doopcode(dd2tbl[j].mcode);
			kcnt += fprintf(fp, "%c+", index);
			v = (word) pgmmem[i + 2] & 0xff;
			cptr = find_entry(v, symbol_count, sym_val_index);
			if (cptr == NULL)
				puthex(v);
			else
				kcnt += fprintf(fp, "%s", cptr);
			putc(')', fp);
			kcnt++;
			opcount = 3;
			return(0);

		case OPT_DD_CB:
			j = pgmmem[i + 3];							/* get cb ext byte */
			if (j == 0x36 || (j & 7) != 6)
				return(0);
			if (j < 0x40)
			{
				k = j >> 3;
				doopcode(ddcbtbl[k].mcode);
			}
			else
			{
				k = (j >> 6) + 7;
				doopcode(ddcbtbl[k].mcode);
				putc(((j >> 3) & 7) | 0x30, fp);
				putc(',', fp);
				kcnt += 2;
			}
			kcnt += fprintf(fp, "(i%c+", index);
			v = (word) pgmmem[i + 2] & 0xff;
			cptr = find_entry(v, symbol_count, sym_val_index);
			if (cptr == NULL)
				puthex(v);
			else
				kcnt += fprintf(fp, "%s", cptr);
			putc(')', fp);
			kcnt++;
			opcount = 4;
			return(0);
	}
	return(0);
}

void indxld1(word i, char reg, char idx)
{
	char			*cptr;
	word			v;

	doopcode("ld ");
	kcnt += fprintf(fp, "%c,(i%c+", reg, idx);
	v = (word) pgmmem[i + 2] & 0xff;
	cptr = find_entry(v, symbol_count, sym_val_index);
	if (cptr == NULL)
		puthex(v);
	else
		kcnt += fprintf(fp, "%s", cptr);
	putc(')', fp);
	kcnt++;
}

void indxld2(word i, char reg, char idx)
{
	char			*cptr;
	word			v;

	doopcode("ld ");
	kcnt += fprintf(fp, "(i%c+", idx);
	v = (word) pgmmem[i + 2] & 0xff;
	cptr = find_entry(v, symbol_count, sym_val_index);
	if (cptr == NULL)
		puthex(v);
	else
		kcnt += fprintf(fp, "%s", cptr);
	kcnt += fprintf(fp, "),%c", reg);
}

/*********************************************************************
 *																							*
 *						Pass three of disassembly									*
 *	Search for references to un-initialized data or split references	*
 *	and, if found, generate EQU statements for them.						*
 *																							*
 *********************************************************************/

void pass3(void)
{
	word	i, j, k, index, val;
	struct sym	*ptr;
	char	*cptr;
	byte	pflag;

	printf("\nPass 3 0000");

	/* search label table for labels referenced but not generated */

	j = 1;
	for (index=0; index<label_count; index++)
	{
		ptr = lab_val_index[index];
		if (ptr->used)
		{
			val = ptr->val;
			val = (word) pgmflags[val];
			val &= (PF_NOINIT | PF_CLREF | PF_SPLIT | PF_REF);
			if (val == (PF_REF | PF_SPLIT) || val == (PF_REF | PF_NOINIT))
			{
				if (j)								/* do header if first one */
				{
					j = 0;
					if (!newline || dump)
						fprintf(fp, "\n;");
					fprintf(fp, "\n;\tlabel equates\n;\n;"
						"  these are labels in the control file that reference\n;"
						"  the middle of a multibyte instruction or reference\n;"
						"  an address outside the initialized space\n;");
				}
				fprintf(fp, "\n%s\tequ\t", ptr->name);
				puthex(ptr->val);
				newline = 0;
			}
		}
	}

	/* now do equates for symbol table */

	j = 1;
	for (index=0; index<symbol_count; index++)
	{
		ptr = sym_val_index[index];
		if (ptr->used)								/* do header if first one */
		{
			if (j)
			{
				j = 0;
				if (!newline || dump)
					fprintf(fp, "\n;");
				fprintf(fp, "\n;\tsymbol equates\n;\n;"
								"  these are symbols from the control\n;"
								"  file that are referenced in the code\n;");
			}
			fprintf(fp, "\n%s\tequ\t", ptr->name);
			puthex(ptr->val);
			newline = 0;
		}
	}

	j = 1;
	for (i=0; ; )
	{
		k = i & 0xfff;
		pflag = pgmflags[i];

		/* if location is referenced and un-initialized or is a split ref */

		if (MISC_EQU_TAG)
		{
			cptr = find_entry(i, label_count, lab_val_index);
			if (cptr == NULL)					/* if not in label list */
			{
				if (j)							/* do header if first one */
				{
					j = 0;
					if (!newline || dump)
						fprintf(fp, "\n;");
					fprintf(fp, "\n;\tmiscellaneous equates\n;\n;"
									"  these are addresses referenced in the code but\n;"
									"  which are in the middle of a multibyte instruction\n;"
									"  or are addresses outside the initialized space\n;");
					newline = 0;
				}
				fprintf(fp, "\nX%04x\tequ\t", i);		/* do EQU statement */
				puthex(i);
			}
		}
		i++;
		if (!(i & 0xffff))	/* the '& 0xffff' is required since GCC */
			break;				/* thinks an unsigned short int is 32 bits */
		if ((i & 0xfff) < k)						/* go figure */
			printf("\rPass 3 %04x", i);
	}

	printf("\rPass 3 - Equate generation complete");
	if (!newline || dump)
		fprintf(fp, "\n");
	fprintf(fp, ";\n\tend\n;\n\n");
	fflush(fp);
	fclose(fp);
}												/*  End of Pass 3   */

/***************************************
 *													*
 *		Output opcode for current code	*
 *													*
 ***************************************/

void doopcode(char *mnem)
{
	char	c;

	c = *mnem++;
	while (c)						/* output text from opcode table */
	{
		if (c == ' ')				/* convert spaces to tabs */
		{
			putc('\t', fp);
			kcnt = (kcnt + 8) & 0x78;
		}
		else
		{
			putc(c, fp);
			kcnt++;
		}
		c = *mnem++;
	}
}

/*********************************************************************
 *																							*
 *	add label to output line if current location marked as referenced	*
 *																							*
 *********************************************************************/

void chk_ref(word i)
{
	int	cnt;
	char	*cptr;

	if ((pgmflags[i] & (PF_REF | PF_CLREF)) == PF_REF)
	{
		cptr = find_entry(i, label_count, lab_val_index);			/* see if label exists */
		if (cptr == NULL)
			cnt = fprintf(fp, "\nX%04x:", i);	/* if not, output hex value */
		else
			cnt = fprintf(fp, "\n%s:", cptr);	/* else output label text */
		if (cnt > 8)
			fprintf(fp, "\n\t");
		else
			fprintf(fp, "\t");
	}
	else
		fprintf(fp, "\n\t");
}

/***************************************************
 *																	*
 *		Check for reference to address in middle of	*
 *		code and flag split reference if true			*
 *																	*
 ***************************************************/

void splitcheck(word i)
{
	if (!(pgmflags[i] & PF_CLREF))		/* ignore if not referenced */
		pgmflags[i] |= PF_SPLIT;			/* else flag split ref */
}

/************************************************************************
 *																								*
 *		Check if data is printable ascii other than the string delimiter	*
 *																								*
 ************************************************************************/

int is_ascii(byte data)
{
	if (data < ' ' || data > 0x7e || data == '\'')
		return(0);
	return(1);
}

/************************************
 *												*
 *		Output hexadecimal operand		*
 *												*
 ************************************/

void puthex(word j)
{
	if (j < 10)
		kcnt += fprintf(fp, "%x", j);
	else if (j < 16)
		kcnt += fprintf(fp, "0%xh", j);
	else if (j < 0xa0)
		kcnt += fprintf(fp, "%xh", j);
	else if (j < 0x100)
		kcnt += fprintf(fp, "0%xh", j);
	else if (j < 0xa00)
		kcnt += fprintf(fp, "%xh", j);
	else if (j < 0x1000)
		kcnt += fprintf(fp, "0%xh", j);
	else if (j < 0xa000)
		kcnt += fprintf(fp, "%xh", j);
	else
		kcnt += fprintf(fp, "0%xh", j);
}

/******************************************
 *														*
 *		Convert code to printable ascii		*
 *														*
 ******************************************/

int ascii(int i)
{
	i = i & 0x7f;
	if (i == 0x7f)
		return ('.');
	else if (i < 0x20)
		return ('.');
	else
		return (i);
}

/* end of dz80p2.c */

